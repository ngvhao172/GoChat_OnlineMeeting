class NotificationSub {
    constructor(id, userId, subScription, createdAt) {
        this.id = id;
        this.userId = userId;
        this.subScription = subScription;
        this.createdAt = createdAt;
    }
}
module.exports = NotificationSub;